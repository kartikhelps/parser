#!/bin/bash
npm create vite@latest my-react-app -- --template react
cd my-react-app
npm i

