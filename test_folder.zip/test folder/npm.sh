mkdir app_project
cd app_project
npm init 