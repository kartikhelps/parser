const fs = require('fs');
const Handlebars = require('handlebars');


const createFile = async (obj, name, path) => {
  // console.log(path,"here is it",name , obj)
  try {
    if (path) {
      fs.mkdirSync(path, { recursive: true })
      fs.writeFileSync(path + name, obj)
      return true
    } else {
      fs.writeFileSync(name, obj)
      return true
    }
  } catch (e) {
    console.log(e, "here is msg")
  }
}

// Register custom switch helper
Handlebars.registerHelper('switch', function(value, options) {
  this.switch_value = value;
  var html = options.fn(this);
  delete this.switch_value;
  return html;
});

// Register custom case helper
Handlebars.registerHelper('case', function(value, options) {
  if (value === this.switch_value) {
    return options.fn(this);
  }
});

// Register custom default helper
Handlebars.registerHelper('default', function(options) {
  if (typeof this.switch_value === 'undefined') {
    return options.fn(this);
  }
});

// Read the template file

const jsonData = require('./data.json')

Handlebars.registerHelper('regex',function(value,name,options){
   if (value.includes("Regex")) {
    return `!(${value}.test(formData.${name.split(" ").join("").toLowerCase()}}))`
  } else {
    map = { eq: "===", gt: ">",lt:"<",lteq:"<=="}
    v = value.split(/[.()]/)
    return `!(formData.${name.split(" ").join("").toLowerCase()} ${map[v[1].trim()]} formData.${v[2]})`
  }
});
Handlebars.registerHelper('loud', function(string) {
   return string.toUpperCase()
});


Handlebars.registerHelper('fun', function(value,) {
  console.log("value", value)
  main(value)

      
  return "";
});



const main = (data, file, out, path) => {
  // console.log(data)
  const templateContent = fs.readFileSync(file, 'utf-8');
  const template = Handlebars.compile(templateContent);
  const val = data.screens[0].sections[2].components[0]
  const componentName = data.screens[0].sections[2].name
  const reactFileContent = template(val);

  console.log("here is data",componentName)
  createFile(reactFileContent, out, path)
}



main(jsonData, './formbuilder.hbs', 'kartikmax.jsx')
