// Register custom switch helper
Handlebars.registerHelper('switch', function (value, options) {
  this.switch_value = value;
  var html = options.fn(this);
  delete this.switch_value;
  return html;
});

// Register custom case helper
Handlebars.registerHelper('case', function (value, options) {
  if (value === this.switch_value) {
    return options.fn(this);
  }
});

// Register custom default helper
Handlebars.registerHelper('default', function (options) {
  if (typeof this.switch_value === 'undefined') {
    return options.fn(this);
  }
});