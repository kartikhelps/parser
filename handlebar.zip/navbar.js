const fs = require('fs');
const Handlebars = require('handlebars');

const createFile = async (obj, name, path) => {
  try {
    if (path) {
      fs.mkdirSync(path, { recursive: true })
      fs.writeFileSync(path + name, obj)
      return true
    } else {
      fs.writeFileSync(name, obj)
      return true
    }
  } catch (e) {
    return e.message
  }
}

const data = { data:[
                {
                  "name": "Signin",
                  "fieldType": "",
                  "mandatory": false,
                  "placeholder": "",
                  "regexValidation": "",
                  "mapField": "",
                  "regexMsg": "",
                  "masters": "",
                  "defaultValue": "",
                  "type": "ShowSection",
                  "Actions": [
                      {
                        "step": 1,
                        "type": "ShowSection",
                        "fields": {
                          "Signin": true,
                          "Verification": false,
                          "Signup": false
                        }
                      }
                    ]
                },
                {
                  "name": "Signup",
                  "fieldType": "",
                  "mandatory": false,
                  "placeholder": "",
                  "regexValidation": "",
                  "mapField": "",
                  "masters": "",
                  "regexMsg": "",
                  "defaultValue": "",
                  "type": "ShowSection",
                  "Actions": [
                      {
                        "step": 1,
                        "type": "ShowSection",
                        "fields": {
                          "Signin": false,
                          "Verification": false,
                          "Signup": true
                        }
                      }
                    ]
                },
                
              ]};

const actions = {Actions:[{step:1,
        type:"ShowSection",
        fields:    
          {Signin:true,Verification:false,Signup:false}}
        ]}

console.log(actions.Actions[0].fields)



const main = (data, file, out, path) => {

  try{
    const templateContent = fs.readFileSync(file, 'utf-8');
    const template = Handlebars.compile(templateContent);
    const reactFileContent = template(data);

    createFile(reactFileContent, out, path)
  }
  catch(err){
    console.log(err.message,"a2")
  }

}

main(data,'./templates/navbar.hbs','navbar.jsx')
