import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import { ToastContainer } from "react-toastify"
import "react-toastify/dist/ReactToastify.css"
import Login from "./pages/Login"
function App() {
  return (
    <>
      <Router>
        <Routes>
<Route path="/Login" element={<Login />} />

        </Routes>
      </Router>
    </>
  )
}

export default App



