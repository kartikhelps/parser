#!/bin/bash

npm create vite@latest my-react-app -- --template react -y 
cd my-react-app
# npm i
#uncomment the above line when you run in local or other than replit

rm src/App.css
rm src/App.jsx
rm src/index.css
rm -r src/assets


