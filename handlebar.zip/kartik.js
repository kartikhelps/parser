const fs = require('fs');
const Handlebars = require('handlebars');

// Read the template file

const jsonData = require('./data.json');

Handlebars.registerHelper('fun', function (value, ) {
  console.log("value",value)
  main(value)
  
  
  return "";
});


const signin = (data,file,out)=>{
  const templateContent = fs.readFileSync(file, 'utf-8');
  const template = Handlebars.compile(templateContent);
  const reactFileContent = template(data.screens[0].sections[1].name);
  console.log(data.screens[0].sections[1].name)

// Save the generated content to a new React file
  fs.writeFileSync('./SignIn.jsx', reactFileContent);
  console.log("done")
}

signin(jsonData,'./pageIndex.hbs')