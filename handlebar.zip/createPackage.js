const fs = require('fs');
const Handlebars = require('handlebars');
const createFile = async (obj, name, path) => {
  try {
    if (path) {
      fs.mkdirSync(path, { recursive: true })
      fs.writeFileSync(path + name, obj)
      return true
    } else {
      fs.writeFileSync(name, obj)
      return true
    }
  } catch (e) {
    return e.message
  }
} 


const jsonData = {
  "name": "template-handlebar",
  "private": true,
  "version": "0.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "lint": "eslint src --ext js,jsx --report-unused-disable-directives --max-warnings 0",
    "preview": "vite preview"
  },
  "dependencies": {
    "@emotion/react": "^11.10.6",
    "@emotion/styled": "^11.10.6",
    "@mui/material": "^5.12.1",
    "@mui/styles": "^5.12.0",
    "axios": "^1.3.6",
    "handlebars": "^4.7.7",
    "node-fetch": "^3.2.6",
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-toastify": "^9.1.2"
  },
  "devDependencies": {
    "@types/react": "^18.0.28",
    "@types/react-dom": "^18.0.11",
    "@vitejs/plugin-react": "^4.0.0-beta.0",
    "eslint": "^8.38.0",
    "eslint-plugin-react": "^7.32.2",
    "eslint-plugin-react-hooks": "^4.6.0",
    "eslint-plugin-react-refresh": "^0.3.4",
    "vite": "^4.3.0"
  }
}


const main = (data, file, out, path) => {
  // console.log(data)
  const templateContent = fs.readFileSync(file, 'utf-8');
  const template = Handlebars.compile(templateContent);
 
  const reactFileContent = template(jsonData);

  // console.log("here is data",componentName)
  createFile(reactFileContent, out, path)
}



main(jsonData, './createPackage.hbs', 'packagel.json')
