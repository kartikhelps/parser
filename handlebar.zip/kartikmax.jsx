import React, { useState,useEffect } from 'react';
import { makeStyles } from '@mui/styles';

import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button'




const useStyles = makeStyles((theme) => ({
  formControl: {
    margin: 20,
    minWidth: 120,
  },
}));

const countries = [
  {
    nameH: 'USA',
    code: 'US',
  },
  { 
    nameH: 'Canada',
    code: 'CA',
  },
  {
    nameH: 'Mexico',
    code: 'MX',
  },
];

function CustomForm() {
  const classes = useStyles();

  const [formData, setFormData] = useState({
    country: '',
    username: '',
    password: '',
    confirmPassword: '',
    submit: '',
  });

  const handleChange = (e) => {
    const { nameH, value, type, checked } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [nameH]: type === 'checkbox' ? checked : value,
    }));
  };
  
useEffect(async()=>{
  const fetchData=await axios.post('{{process.env.URL}}user',{
    username:formData.username,
    password:formData.password
  }).then(res)=>{
    console.log(res.json)
  }.catch(err)=>{
  console.log(err)
  }
  fetchData()
},[])
  const handleSubmit = (e) => {
    e.preventDefault();
    
  };
 }
}
 
  return (
    <FormControl onSubmit={handleSubmit}>
      

   

      <FormControl classnameH={classes.formControl} fullWidth>
        <InputLabel>Country</InputLabel>
        <Select
          nameH="country"
          value={formData.country}
          label="Country"
          onChange={handleChange}
        >
          {countries.map((country) => (
            <MenuItem key={country.code} value={country.code}>
              {country.nameH}
            </MenuItem>
          ))}
        </Select>
      </FormControl>



      

      <TextField
        label="username"
        nameH="Username"
        value={ formData.username }
        onChange={handleChange}
        type='text'
        margin="normal"
        fullWidth 
        helperText={(!(Regex.email.test(formData.username) && "Format not Correct"}
         error={ !(Regex.email.test(formData.username})) }
      
      />
   




      

      <TextField
        label="password"
        nameH="Password"
        value={ formData.password }
        onChange={handleChange}
        margin="normal"
        fullWidth
        type="password"
        helperText={(!(Regex.password.test(formData.password) && "Should have at least 5 characters with 1 number"}
        error={ !(Regex.password.test(formData.password})) }
        
 
      />
   




      

      <TextField
        label="confirmPassword"
        nameH="Confirm Password"
        value={ formData.confirmPassword }
        onChange={handleChange}
        margin="normal"
        fullWidth
        type="password"
        helperText={(!(Field.eq(password).test(formData.confirmPassword) && "Same as Password"}
        error={ !(formData.confirmpassword === formData.password) }
        
 
      />
   




      

   


                        <Button type="submit" variant="contained" color="primary">
        Submit
      </Button> 



   
   
    </FormControl>  
  );
}

export default CustomForm;
