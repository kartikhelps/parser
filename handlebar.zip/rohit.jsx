import { useEffect, useState } from "react"
import { Link, useNavigate } from "react-router-dom"
import axios from 'axios';

import Verification from "./Verification"
import Header from "./Header"
import Onload_Config from "./Onload_Config"
import Signin from "./Signin"
import Signup from "./Signup"
import Verification from "./Verification"
import Header from "./Header"


const Login = () => {
  const [section,setSection] = useState({SigninState : true,SignupState : false,VerificationState : false,})
  const [vars,setVars] = useState({})
  const [isLoading,setLoad] =useState(false)



  useEffect(() => {
    axios.get("http://localhost:5000/api/master/").then((res) => {
      setVars(res.data.data)
      setLoad(true)

    });
  }, []);
  
  return (
  <>
  {<Onload_Config vars={vars}  setSection={setSection}/>}
  {<Signin vars={vars}  setSection={setSection}/>}
  {<Signup vars={vars}  setSection={setSection}/>}
  {<Verification vars={vars}  setSection={setSection}/>}
  {<Header vars={vars}  setSection={setSection}/>}
  </>
  )
}

export default Login

